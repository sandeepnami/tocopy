import pygetwindow as gw
import pyautogui
import pydirectinput
import time

# Set the number of pages you want to scroll through
no_of_pgs = 2
browser_title = "Copilot"
wait_time = 2  # seconds

#functions
from PIL import Image
import os

# Function to combine all screenshots into one image
def combine_screenshots(screenshots, output_filename):
    # Assume all images are the same width and height
    images = [Image.open(screenshot) for screenshot in screenshots]
    widths, heights = zip(*(i.size for i in images))

    # Create a new image with the combined height of all screenshots
    total_height = sum(heights)
    max_width = max(widths)
    combined_image = Image.new('RGB', (max_width, total_height))

    # Paste each screenshot into the combined image
    y_offset = 0
    for im in images:
        combined_image.paste(im, (0, y_offset))
        y_offset += im.height

    # Save the combined image
    combined_image.save(output_filename)
    print(f"Combined image saved as {output_filename}")

browser_window = gw.getWindowsWithTitle(browser_title)[0]
if browser_window:
    browser_window.activate()
else:
    print("Browser window not found.")

for i in range(no_of_pgs):
    # Take a screenshot
    screenshot = pyautogui.screenshot()
    screenshot.save(f'screenshot_{i+1}.png')
        # Page down using pydirectinput
    pydirectinput.press('pagedown')    
    # Wait for the page to scroll and the content to load
    time.sleep(wait_time)

ss_array = ["screenshot_"+str(i) for i in range(no_of_pgs)]
print(ss_array)
combine_screenshots(ss_array)


