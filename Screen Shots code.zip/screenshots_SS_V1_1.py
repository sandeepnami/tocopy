import pygetwindow as gw
import win32gui
import pyautogui
import pydirectinput
import time
from PIL import Image
import os


# Set the number of pages you want to scroll through
no_of_pgs = 6
browser_title = "Copilot"
wait_time = 2  # seconds

# Functions
def get_window(browser_title):
    browser_window = gw.getWindowsWithTitle(browser_title)[0]
    if browser_window:
        browser_window.activate()
    else:
        print("Browser window not found.")

def get_active_window_SS():
    # Get the handle to the active window
    get_window(browser_title)
    time.sleep(wait_time)
    hwnd = win32gui.GetForegroundWindow()
    # Get the window's bounding box
    x, y, x1, y1 = win32gui.GetWindowRect(hwnd)
    width = x1 - x
    height = y1 - y
    # Take a screenshot of the active window
    screenshot = pyautogui.screenshot(region=(x, y, width, height))    
    # Save the screenshot
    screenshot.save('active_window_screenshot.png')

def take_SS(no_of_pgs):
    for i in range(no_of_pgs):
        # Take a screenshot
        screenshot = pyautogui.screenshot()
        screenshot.save(f'screenshot_{i}.png')
            # Page down using pydirectinput
        pydirectinput.press('pagedown')    
        # Wait for the page to scroll and the content to load
        time.sleep(wait_time)

def combine_screenshots(screenshots, output_filename):
    # Assume all images are the same width and height
    images = [Image.open(screenshot) for screenshot in screenshots]
    widths, heights = zip(*(i.size for i in images))

    # Create a new image with the combined height of all screenshots
    total_height = sum(heights)
    max_width = max(widths)
    combined_image = Image.new('RGB', (max_width, total_height))

    # Paste each screenshot into the combined image
    y_offset = 0
    for im in images:
        combined_image.paste(im, (0, y_offset))
        y_offset += im.height

    # Save the combined image
    combined_image.save(output_filename)
    print(f"Combined image saved as {output_filename}")

# activate_window(browser_title)
# take_SS(no_of_pgs)

get_active_window_SS()

# ss_array = ["screenshot_"+str(i)+".png" for i in range(no_of_pgs)]
# print(ss_array)
# combine_screenshots(ss_array,"combined_SS.png")


