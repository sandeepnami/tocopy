import pygetwindow as gw
import pyautogui

# Function to take a screenshot of the currently active browser window
def screenshot_active_window(browser_title):
    # Find the browser window by its title
    browser_window = gw.getWindowsWithTitle(browser_title)[0]
    
    # If the window is found, bring it to the foreground
    if browser_window:
        browser_window.activate()
        
        # Wait for the window to be active
        pyautogui.sleep(2)
        
        # Take a screenshot of the entire screen
        screenshot = pyautogui.screenshot()
        
        # Save the screenshot
        screenshot.save(f"{browser_title}_screenshot.png")
        print(f"Screenshot saved as {browser_title}_screenshot.png")
    else:
        print("Browser window not found.")

# Example usage:
# screenshot_active_window("Mozilla Firefox")
# Note: Replace "Mozilla Firefox" with the actual title of your browser window.
