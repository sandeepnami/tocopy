import pygetwindow as gw
import win32gui
import pyautogui
import pydirectinput
import time
from PIL import Image
import os


# Set the number of pages you want to scroll through
no_of_pgs = 12
browser_title = "Copilot"
wait_time = 2  # seconds
"""
screenshot.crop((left, top, right, bottom))
(0,0)-----------------------
|                          |
|                          |
|   (Left, Top)            | 
|      ------------        |
|      |          |        |
|      |  CROP    |        |
|      |  AREA    |        |
|      |          |        |
|      |          |        |
|      ------------        |
|         (Right, Bottom)  |
|                          |
---------------------------

"""
crop_area = (0, 100, 1920, 1080)
# Get the dimensions of your screen
screen_width, screen_height = pyautogui.size()

# Functions
def get_crop_area(desired_width, desired_height):
    # Define the crop area percentages (left, top, right, bottom)
    left_percentage = 15    # Crop 10% from the left
    top_percentage = 15   # Crop 10% from the top
    right_percentage = 85   # Crop up to 90% from the left
    bottom_percentage = 85  # Crop up to 90% from the top

    # Convert percentages to pixel values
    left = (left_percentage / 100) * screen_width
    top = (top_percentage / 100) * screen_height
    right = (right_percentage / 100) * screen_width
    bottom = (bottom_percentage / 100) * screen_height
    return(left,top,right,bottom) 

def get_window(browser_title):
    browser_window = gw.getWindowsWithTitle(browser_title)[0]
    if browser_window:
        browser_window.activate()
    else:
        print("Browser window not found.")

def get_active_window_SS():
    # Get the handle to the active window
    get_window(browser_title)
    time.sleep(wait_time)
    hwnd = win32gui.GetForegroundWindow()
    # Get the window's bounding box
    x, y, x1, y1 = win32gui.GetWindowRect(hwnd)
    width = x1 - x
    height = y1 - y
    # Take a screenshot of the active window
    screenshot = pyautogui.screenshot(region=(x, y, width, height))    
    # Save the screenshot
    screenshot.save('active_window_screenshot.png')

def take_SS(no_of_pgs,crop_area=(0,0,0,0)):
    for i in range(no_of_pgs):
        # Take a screenshot
        screenshot = pyautogui.screenshot()
        # Crop the screenshot to remove the browser header
        cropped_screenshot = screenshot.crop(crop_area)
        cropped_screenshot.save(f'Cscreenshot_{i+1}.png')
            # Page down using pydirectinput
        pydirectinput.press('pagedown')    
        # Wait for the page to scroll and the content to load
        time.sleep(wait_time)

def combine_screenshots(screenshots, output_filename):
    # Assume all images are the same width and height
    images = [Image.open(screenshot) for screenshot in screenshots]
    widths, heights = zip(*(i.size for i in images))

    # Create a new image with the combined height of all screenshots
    total_height = sum(heights)
    max_width = max(widths)
    combined_image = Image.new('RGB', (max_width, total_height))

    # Paste each screenshot into the combined image
    y_offset = 0
    for im in images:
        combined_image.paste(im, (0, y_offset))
        y_offset += im.height

    # Save the combined image
    combined_image.save(output_filename)
    print(f"Combined image saved as {output_filename}")

get_window(browser_title)
time.sleep(wait_time)
crop_area = get_crop_area(screen_width, screen_height)
# print(f"screen_width={screen_width} screen_height={screen_height} crop_area={crop_area}")
take_SS(no_of_pgs, crop_area)

get_active_window_SS()

ss_array = ["Cscreenshot_"+str(i)+".png" for i in range(0,no_of_pgs)]
print(ss_array)
combine_screenshots(ss_array,"nakshatras_SS.png")


